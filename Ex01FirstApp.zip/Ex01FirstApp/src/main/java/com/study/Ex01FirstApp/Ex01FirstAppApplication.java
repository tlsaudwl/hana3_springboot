package com.study.Ex01FirstApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ex01FirstAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ex01FirstAppApplication.class, args);
	}

}
