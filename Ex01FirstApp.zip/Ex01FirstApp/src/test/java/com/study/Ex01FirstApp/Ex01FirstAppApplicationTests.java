package com.study.Ex01FirstApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex01FirstAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
