package com.study.Pr03VM_teacher;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Pr03VmTeacherApplicationTests {

	@Test
	void contextLoads() {
	}

}
