package com.study.Pr03VM_teacher;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pr03VmTeacherApplication {

	public static void main(String[] args) {
		SpringApplication.run(Pr03VmTeacherApplication.class, args);
	}

}
